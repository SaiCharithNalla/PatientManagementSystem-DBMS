<?php
include 'connect.php';
$ID=$_REQUEST['doc_id'];
// sql to delete a record
$sql = "DELETE FROM doctor WHERE doc_id='$ID'";

if ($con->query($sql) === true) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $con->error;
}

$con->close();
?>