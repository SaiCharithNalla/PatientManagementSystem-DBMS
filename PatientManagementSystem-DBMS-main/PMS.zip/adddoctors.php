<!DOCTYPE html>
<html>

<head>
	<title>Add Doctors</title>
</head>

<body>
	<center>
		<?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$ID = $_REQUEST['doc_id'];
		$name = $_REQUEST['doc_name'];
		$type = $_REQUEST['doc_type'];
		$specialisation = $_REQUEST['doc_spec'];
		$qual = $_REQUEST['doc_qual'];
		$exp = $_REQUEST['doc_exp'];
		// Performing insert query execution
		// here our table name is doctor
		$sql = "INSERT INTO doctor VALUES ('$ID',
			'$name','$type','$specialisation','$qual','$exp')";
		
		if(mysqli_query($con, $sql)){
			echo "<h3>Data stored in a database successfully.";
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($con);
		}
		
		// Close connection
		mysqli_close($con);
		?>
	</center>
</body>

</html>
