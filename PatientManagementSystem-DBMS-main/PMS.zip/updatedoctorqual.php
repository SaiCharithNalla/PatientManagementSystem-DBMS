<?php
include 'connect.php';
$ID=$_REQUEST['doc_id'];
$qual=$_REQUEST['doc_qual'];
$sql = "UPDATE doctor SET doc_qual='$qual' WHERE doc_id='$ID'";
if($con->query($sql) === true){
	echo "Record was updated successfully.";
} else {
	echo "ERROR: Could not able to execute $sql. "
							. mysqli_error($con);
}
mysqli_close($con);
?>
