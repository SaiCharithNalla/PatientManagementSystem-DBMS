<?php
//Connection for database
include 'connect.php';
//Select Database
$sql = "SELECT * FROM Patient";
$result = $con->query($sql);
?>
<!doctype html>
<html>
    <style>
        body{
            background-color:rgb(251, 195, 143);
        }
        table, th, td {
            border: 2px solid black;
            border-collapse: collapse;
            text-align:center;
            }
            th, td {
            padding-top: 30px;
            padding-bottom: 20px;
            padding-left: 40px;
            padding-right: 40px;
            }
    </style>
<body>
<h1 align="center">Patient Details</h1>
<center><table>
<tr>
<th>Pt_id</th>
<th>Pt_name</th>
<th>Bill_num</th>
<th>Disease</th>
<th>Gender</th>
<th>Pt_address</th>
<th>Admission_date</th>
<th>Discharge_date</th>
<th>is_dead</th>
<th>Doc_id</th>
</tr>
<?php
//Fetch Data form database
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>
 <td><?php echo $row['pt_id']; ?></td>
 <td><?php echo $row['pt_name']; ?></td>
 <td><?php echo $row['bill_num']; ?></td>
 <td><?php echo $row['disease']; ?></td>
 <td><?php echo $row['gender']; ?></td>
 <td><?php echo $row['pt_add']; ?></td>
 <td><?php echo $row['adm_date']; ?></td>
 <td><?php echo $row['dsc_date']; ?></td>
 <td><?php echo $row['is_dead']; ?></td>
 <td><?php echo $row['doc_id']; ?></td>
 </tr>
 <?php
 }
}
else
{
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table></center>
</body>
</html>