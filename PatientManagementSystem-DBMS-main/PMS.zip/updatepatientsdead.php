<?php
include 'connect.php';
$ID=$_REQUEST['pt_id'];
$Admissiondate=$_REQUEST['adm_date'];
$dead=$_REQUEST['is_dead'];
$sql = "UPDATE patient SET is_dead='$dead' WHERE pt_id='$ID' AND adm_date='$Admissiondate'";
if($con->query($sql) === true){
	echo "Record was updated successfully.";
} else {
	echo "ERROR: Could not able to execute $sql. "
							. mysqli_error($con);
}
mysqli_close($con);
?>
