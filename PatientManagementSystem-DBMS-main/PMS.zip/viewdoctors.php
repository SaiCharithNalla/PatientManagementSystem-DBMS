<?php
//Connection for database
include 'connect.php';
//Select Database
$sql = "SELECT * FROM Doctor";
$result = $con->query($sql);
?>
<!doctype html>
<html>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body{
            background-color:rgb(231, 221, 131);
        }
        table, th, td {
            border: 2px solid black;
            border-collapse: collapse;
            text-align:center;
            }
            th, td {
            padding-top: 30px;
            padding-bottom: 20px;
            padding-left: 60px;
            padding-right: 60px;
            }
            #myInput {
            background-image: url('https://www.freepnglogos.com/uploads/search-png/search-icon-clip-art-clkerm-vector-clip-art-online-8.png');
            background-size: 20px 20px;
            background-position: 10px 10px;
            background-repeat: no-repeat;
            width: 800px;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
            }
    </style>
<body>
<h1 align="center">Doctor Details</h1>
<center><input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name"></center>

<center><table id="myTable">
<tr>
<th>doc_id</th>
<th>doc_name</th>
<th>doc_type</th>
<th>doc_spec</th>
<th>doc_qual</th>
<th>doc_exp</th>
</tr>
<?php
//Fetch Data form database
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>
 <td><?php echo $row['doc_id']; ?></td>
 <td><?php echo $row['doc_name']; ?></td>
 <td><?php echo $row['doc_type']; ?></td>
 <td><?php echo $row['doc_spec']; ?></td>
 <td><?php echo $row['doc_qual']; ?></td>
 <td><?php echo $row['doc_exp']; ?></td>
 </tr>
 <?php
 }
}
else
{
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table></center>

</body>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</html>