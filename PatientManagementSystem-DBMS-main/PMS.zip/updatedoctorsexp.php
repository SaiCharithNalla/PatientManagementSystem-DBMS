<?php
include 'connect.php';
$ID=$_REQUEST['doc_id'];
$exp=$_REQUEST['doc_exp'];
$sql = "UPDATE doctor SET doc_exp='$exp' WHERE doc_id='$ID'";
if($con->query($sql) === true){
	echo "Record was updated successfully.";
} else {
	echo "ERROR: Could not able to execute $sql. "
							. mysqli_error($con);
}
mysqli_close($con);
?>
