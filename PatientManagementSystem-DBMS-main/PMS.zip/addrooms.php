<!DOCTYPE html>
<html>

<head>
	<title>Add Rooms</title>
</head>

<body>
	<center>
		<?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$ID = $_REQUEST['pt_id'];
		$name = $_REQUEST['pt_name'];
		$duration = $_REQUEST['room_duration'];
		$cost = $_REQUEST['room_cost'];
		$roomid = $_REQUEST['room_id'];
		$type = $_REQUEST['room_type'];
        $roomdate = $_REQUEST['room_date'];
        $disease = $_REQUEST['disease'];
        $admissiondate= $_REQUEST['adm_date'];
		// Performing insert query execution
		// here our table name is patient
		$sql = "INSERT INTO room VALUES ('$ID',
			'$name','$duration','$cost','$roomid','$type','$roomdate','$disease','$admissiondate')";
		
		if(mysqli_query($con, $sql)){
			echo "<h3>Data stored in a database successfully.";
		}else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($con);
		}
		
		// Close connection
		mysqli_close($con);
		?>
	</center>
</body>

</html>
