<!DOCTYPE html>
<html>

<head>
	<title>Add Bill</title>
</head>

<body>
	<center>
		<?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$ID = $_REQUEST['pt_id'];
		$name = $_REQUEST['pt_name'];
		$bill = $_REQUEST['bill_num'];
		$disease = $_REQUEST['disease'];
        $admissiondate = $_REQUEST['adm_date'];
        $medprice=$_REQUEST['med_price'];
        $doccharge=$_REQUEST['doctor_charge'];
        $labcharge=$_REQUEST['laboratory_charge'];
        $roomcost=$_REQUEST['room_cost'];
        $total=$_REQUEST['total_bill'];
		// Performing insert query execution
		// here our table name is patient
		$sql = "INSERT INTO bills VALUES ('$bill','$ID',
			'$name','$medprice','$doccharge',' $labcharge','$roomcost','$total','$disease','$admissiondate')";
		if(mysqli_query($con, $sql)){
			echo "<h3>Data stored in a database successfully.";
		}else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($con);
		}
		
		// Close connection
		mysqli_close($con);
		?>
	</center>
</body>

</html>
