<!DOCTYPE html>
<html>

<head>
	<title>Add Online</title>
</head>

<body>
	<center>
		<?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$ID = $_REQUEST['pt_id'];
        $DID = $_REQUEST['doc_id'];
		$symp = $_REQUEST['symptoms'];
		$med = $_REQUEST['medication'];
        $disease = $_REQUEST['disease'];
        $admissiondate= $_REQUEST['adm_date'];
		// Performing insert query execution
		// here our table name is patient
		$sql = "INSERT INTO online_consultation VALUES ('$ID',
			'$DID','$symp','$med','$disease','$admissiondate')";
		
		if(mysqli_query($con, $sql)){
			echo "<h3>Booking has been done.";
		}else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($con);
		}
		
		// Close connection
		mysqli_close($con);
		?>
	</center>
</body>

</html>
