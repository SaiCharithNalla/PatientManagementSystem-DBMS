<?php
include 'connect.php';
$ID=$_REQUEST['pt_id'];
$Admissiondate=$_REQUEST['adm_date'];
// sql to delete a record
$sql = "DELETE FROM patient WHERE pt_id='$ID' AND adm_date='$Admissiondate'";

if ($con->query($sql) === true) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $con->error;
}

$con->close();
?>