<!DOCTYPE html>
<html>

<head>
	<title>Add Patients</title>
</head>

<body>
	<center>
		<?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$ID = $_REQUEST['pt_id'];
		$name = $_REQUEST['pt_name'];
		$bill = $_REQUEST['bill_num'];
		$disease = $_REQUEST['disease'];
		$gender = $_REQUEST['gender'];
		$address = $_REQUEST['pt_add'];
        $admissiondate = $_REQUEST['adm_date'];
        $dischargedate = $_REQUEST['dsc_date'];
        $dead = $_REQUEST['is_dead'];
        $docID = $_REQUEST['doc_id'];
        $dob = $_REQUEST['pt_dob'];
        $age = $_REQUEST['pt_age'];
        $ph1 = $_REQUEST['ph_num1'];
        $ph2 = $_REQUEST['ph_num2'];
		// Performing insert query execution
		// here our table name is patient
		$sql1 = "INSERT INTO patient VALUES ('$ID',
			'$name','$bill','$disease','$gender','$address','$admissiondate','$dischargedate','$dead','$docID')";
		if(mysqli_query($con, $sql1)){
			echo "<h3>Data stored in a database successfully.";
		}else{
			echo "ERROR: Hush! Sorry $sql1. "
				. mysqli_error($con);
		}
		
		// Close connection
		mysqli_close($con);
		?>
        <?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$ID = $_REQUEST['pt_id'];
        $dob = $_REQUEST['pt_dob'];
        $age = $_REQUEST['pt_age'];
		// Performing insert query execution
		// here our table name is patient
		$sql2 = "INSERT INTO patientdob VALUES ('$ID',
        '$dob','$age')";
		
		// Close connection
		mysqli_close($con);
		?>
        <?php
        include 'connect.php';
		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$con = mysqli_connect("localhost", "root", "", "pms");
		
		// Check connection
		if($con === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
        $ph1 = $_REQUEST['ph_num1'];
        $ph2 = $_REQUEST['ph_num2'];
		// Performing insert query execution
		// here our table name is patient
        $sql3 = "INSERT INTO patient_phone_number VALUES ('$ph1',
        '$ph2')";
		
		// Close connection
		mysqli_close($con);
		?>
	</center>
</body>

</html>
